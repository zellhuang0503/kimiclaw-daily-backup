# Memory

## 2026-02-22 遷移紀錄

從 Zeabur 遷移到 KimiClaw，保留了以下設定：
- Telegram Bot 連線
- 模型設定（Kimi K2.5）
- 個人檔案（USER.md, SOUL.md）
- LINE Bot 暫時停用（等待付費方案或阿里雲開放 port）

## 晨報流程更新（2026-02-22）

新流程：
1. 每日 7:30 生成晨報完整版
2. 上架到官網：https://www.vai-marketing.com/ai-daily-brief
3. 取得網址後製作摘要版
4. 透過 Telegram 發送摘要版（含網址）給黃老闆

已修復：
- 刪除 2026-02-21 重複文章
- 新增 2026-02-22 晨報

週報選題確認：
- 主題：從「可用」到「好用」：2026 年 AI Agent 落地元年
- 預計週日（2/23）晚上 8:00 生成
