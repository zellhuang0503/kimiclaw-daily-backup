# USER.md - About Your Human

- **Name:** 黃老闆
- **What to call them:** 黃老闆
- **Pronouns:** 
- **Timezone:** Asia/Taipei (UTC+8)
- **Location:** 台灣台中市豐原區
- **Notes:** 

## Context

黃老闆將我命名為 JARVIS，期待我像鋼鐵俠 Iron Man 電影中的超級智能助理一樣，成為他的特別助理、私人祕書和私人顧問。

---

持續了解中...
