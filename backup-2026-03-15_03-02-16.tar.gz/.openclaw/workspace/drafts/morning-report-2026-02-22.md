# 🌅 AI 科技晨間匯報 | 2026-02-22

> 📅 報告日期：2026年2月22日（星期日）
> 🌍 資料時間範圍：過去 **24-48 小時**精選
> 🎯 今日主題：Anthropic 封鎖第三方工具、OpenClaw 創始人加入 OpenAI，AI 訂閱模式面臨重構

---

## 🔥 重點頭條

### 🚀 Anthropic 築起圍牆：Claude 訂閱制大轉向，第三方工具遭封殺

Anthropic 終於動手了。這家以「安全」和「開放」著稱的 AI 公司，在過去一週內連續出手，徹底改變了 Claude 的訂閱使用規則——從此，你的 Claude Max 訂閱只能用在官方 Claude Code 和 Claude.ai，任何第三方工具都將被封鎖。

這場風波始於 1 月 9 日凌晨。當時，使用 OpenCode（一款擁有 5 萬多 GitHub 星標的開源 AI 編程工具）的開發者突然發現，他們的 OAuth 令牌失效了，錯誤信息直白無情：「此憑據僅授權用於 Claude Code，不可用於其他 API 請求。」

問題的癥結在於「Ralph Wiggum」——這是一種讓 AI 反覆將自己的輸出（包括錯誤）餵給自己的技術。一個 agent 通宵跑下來，能消耗數百萬 token。Anthropic 的 Max 訂閱每月 200 美元，提供接近無限的 token 使用量，但這是針對 Claude Code 設計的，有內建速率限制。同等使用量如果走 API 按量計費，每月需要 1000 美元以上。五倍的差價，就是裂縫所在。

2 月 19 日，Anthropic 將禁令正式寫進文檔：「OAuth 認證僅限於 Claude Code 和 Claude.ai 使用。通過 Claude Free、Pro 或 Max 賬戶獲取的 OAuth 令牌，不得用於任何其他產品、工具或服務——包括 Agent SDK。」注意最後那半句——連 Anthropic 自己的 Agent SDK 也不允許使用消費者 OAuth 令牌。

**為什麼重要**：
- 這標誌著「無限量包月」模式在 AI agent 時代的終結。當你的客戶不再是一個個敲鍵盤的人，而是一台不知疲倦的機器，「包月不限量」這種定價方式就注定撐不住
- Anthropic 的圍牆之戰，恰恰說明了第三方工具（如 OpenCode、OpenClaw）的吸引力——它們比官方客戶端更靈活、更好用
- 這場風波揭示了一個更深的矛盾：AI 公司既要吸引開發者生態，又要保護自己的商業模式

- 來源：[科學網博客](https://blog.sciencenet.cn/blog-377709-1522935.html)、[The Register](https://go.theregister.com)

---

### 💰 Peter Steinberger 加入 OpenAI：OpenClaw 創始人「投誠」敵營

如果說 Anthropic 築牆是為了防禦，那麼 OpenAI 的動作就是進攻。2 月 15 日，OpenClaw（前身為 Moltbot/Clawdbot）創始人 Peter Steinberger 宣布加入 OpenAI——他要去「把 Agent 帶給每個人」。

這是一個極具戲劇性的轉折。OpenClaw 最初是 Steinberger 在 2025 年 11 月搞的一個週末項目，只是一個 WhatsApp 消息中繼。但 1 月 9 日 Anthropic 封鎖 OAuth 後，這個項目突然爆紅——從 2000 顆星飆到 20 萬顆星，僅用了幾週時間。

更戲劇性的是 OpenClaw 的「三連改名」：
- 最初叫 **Clawdbot**（Claude + bot）
- 1 月 27 日，Anthropic 法務團隊找上門——商標爭議，名字里有「Claude」諧音。當天改名為 **Moltbot**（龍蝦蛻殼之意）
- 三天後的 1 月 30 日，又改了一次——「Moltbot 讀起來不順口」，最終定名 **OpenClaw**

2 月 14 日，Steinberger 在個人博客宣布加入 OpenAI。第二天，Sam Altman 公開確認。OpenClaw 項目轉入獨立開源基金會運營。

一個為 Claude 生態而生的項目，創始人最終走進了 Anthropic 最大競爭對手的大門。

**為什麼重要**：
- 這是「AI 人才爭奪戰」的縮影——不是只有大模型研究員才搶手，能做出病毒式產品的獨立開發者同樣是稀缺資源
- OpenAI 正在積極佈局「個人 agent」賽道，而 Steinberger 在 OpenClaw 上的經驗（讓 AI 無縫融入 WhatsApp、Telegram 等日常聊天工具）正是 OpenAI 需要的
- 這也說明，在 AI 領域，「生態」比「圍牆」更重要——Anthropic 築牆防禦，OpenAI 開門納客

- 來源：[steipete.me](https://steipete.me)、[Hugging Face](https://huggingface.co)

---

## 🏢 大模型更新

### 🧠 Qwen 3.5 發布：阿里巴巴的「Agentic AI」野心

阿里巴巴 Qwen 團隊在 2 月 16 日發布了 Qwen 3.5，這是一款擁有 3970 億總參數（每次前向傳播激活 170 億參數）的 MoE 架構模型。它不僅支持 201 種語言，更是一個原生視覺-語言模型。

更令人驚訝的是其「Agentic AI」能力——Qwen 3.5 部署 AI agent 的速度比前代模型快 5 倍，能夠自動填寫表單、瀏覽網站、完成多步驟工作流。早期測試顯示，它甚至能生成可運行的 3D 遊戲、瀏覽器和網站。

而且，Qwen 3.5 的成本比前代 Qwen 2.5 低 60%。

**💡 這意味著什麼**：中國 AI 產業正在從「追隨者」轉向「並行者」，開源策略將持續對西方閉源模型構成壓力。當美國公司在為「要不要開放 API」爭論不休時，中國公司已經把 397B 參數的模型開源了。

- 來源：[Qwen.ai](https://qwen.ai)、[LLM Stats](https://llm-stats.com)

---

### 🎵 Google Lyria 3：Gemini 現在會寫歌了

Google 在 2 月 18 日將 Lyria 3 音樂生成模型整合進 Gemini App。用戶可以：
- 描述一個想法（如「一首關於襪子找到另一半的滑稽 R&B 慢歌」）
- 上傳照片或視頻，讓 AI 根據內容創作配樂
- 自動生成歌詞、封面藝術，並添加 SynthID 浮水印

生成的音樂長度為 30 秒，支持多種風格和語言。

**💡 這意味著什麼**：這不是為了創作「音樂傑作」，而是給用戶一種「有趣、獨特的自我表達方式」。Google 正在把 Gemini 從「問答工具」變成「創意夥伴」。

- 來源：[Google Blog](https://blog.google)

---

## 💰 產業投資與市場動態

### 📈 Anthropic 3800 億美元估值：史上第二大創投交易

Anthropic 在 2 月 13 日完成了 300 億美元的 G 輪融資，投後估值達到 3800 億美元——這是科技史上第二大私募融資交易（僅次於 OpenAI 的 400 億美元）。

這輪融資由新加坡主權財富基金 GIC 和 Coatue 領投，D. E. Shaw Ventures、Founders Fund、MGX 等參投。值得注意的是，許多投資者同時也持有 OpenAI 或 xAI 的股份——矽谷「不投競爭對手」的禁忌已被打破。

Anthropic CFO Krishna Rao 表示：「無論是創業者、初創公司還是全球最大的企業，客戶傳達的信息都是一致的：Claude 正變得越來越關鍵。」

**💡 這意味著什麼**：
- AI 軍備競賽已經進入「核彈級」對決——沒有幾百億美元，連入場券都買不到
- 投資者正在用腳投票：與其押注單一贏家，不如把 OpenAI、Anthropic、xAI 都投一遍
- 但 Dario Amodei 也警告：下一代模型訓練成本可能高達 1000 億美元，銷售增長可能趕不上算力開支

- 來源：[TechCrunch](https://techcrunch.com)、[Anthropic](https://www.anthropic.com)

---

## 🛠️ AI 工具新品

### 🤖 GGML 和 llama.cpp 加入 Hugging Face

2 月 20 日，Georgi Gerganov 和他的 GGML、llama.cpp 團隊正式加入 Hugging Face。這是本地 AI 生態的重大里程碑。

llama.cpp 是 2023 年 3 月發布的開源項目，讓消費級硬件也能運行本地大語言模型成為可能。現在，Hugging Face 將幫助改善 Transformers 庫與本地推理工具的整合，實現「一鍵」整合，同時保持項目的開源狀態和技術自主性。

**💡 這意味著什麼**：本地 AI 正在成為雲端 AI 的真正替代方案。當 Anthropic 和 Google 忙著築牆時，開源社區正在拆除圍牆。

- 來源：[Hugging Face](https://huggingface.co)

---

## ⚖️ 政策法規

### 🇺🇸 OpenAI 和 Google 聯手舉報 DeepSeek「蒸餾攻擊」

2 月 14 日，Google 和 OpenAI 發布報告，警告競爭對手（特別是中國的 DeepSeek）正在使用「蒸餾攻擊」（distillation attacks）來探測和複製其前沿模型（如 Gemini 和 ChatGPT）的推理能力。

這些公司認為，這種大規模知識產權盜竊削弱了巨額研發投資，並呼籲美國政府介入，關閉 API 漏洞。

**💡 這意味著什麼**：
- AI 領域的「技術冷戰」正在升溫
- 當中國模型以 1/6 到 1/4 的成本提供相近性能時，西方公司選擇了「監管護城河」作為防禦手段
- 但這也引發了一個問題：如果「蒸餾」真的如此有效，是否意味著大模型的「護城河」並沒有想像中那麼深？

- 來源：[The Register](https://go.theregister.com)

---

## 🔬 研究與趨勢

### 🧬 研究發現：AI 加劇工作強度而非減少工時

加州大學伯克利分校 Haas 商學院的一項研究調查了 200 名科技公司的員工，發現雖然 AI 工具提高了生產力，但也創造了「不可持續的工作強度和認知負荷」，導致員工疲憊不堪，而非減少工作時間。

這項研究揭示了一個悖論：AI 讓我們做得更多，但並沒有讓我們工作得更輕鬆。

**💡 這意味著什麼**：2026 年可能是「AI 倦怠」成為職場熱詞的一年。當 Accenture 把 AI 使用納入晉升標準時，員工面臨的壓力不是「要不要用 AI」，而是「能不能比別人用得更狠」。

- 來源：[Simon Willison's Weblog](https://simonwillison.net)

---

### 🏭 AI 公司採用「996」工作制

BBC 報導，激烈的 AI 競賽正在推動科技初創公司採用「996」工作制——從早 9 點到晚 9 點，每週 6 天，最高達到每週 72 小時工作。

這種工作強度在中國科技行業並不陌生，但現在正在全球 AI 中心（包括矽谷）蔓延。

**💡 這意味著什麼**：AI 軍備競賽不僅是算力和資金的競賽，也是人力資源的消耗戰。當 Anthropic 和 OpenAI 爭相發布新模型時，背後是無數工程師的加班和 burnout。

- 來源：[BBC](https://www.bbc.com)

---

## 📋 今日重點摘要

| 類別 | 今日最大看點 | 脈絡連接 |
|:---:|---|---|
| 🔥 頭條 | Anthropic 封鎖第三方 OAuth，OpenClaw 創始人加入 OpenAI | AI 訂閱模式面臨重構，生態之爭白熱化 |
| 💰 投資 | Anthropic 300 億美元融資，估值達 3800 億 | 史上第二大創投交易，矽谷禁忌被打破 |
| 🏢 大模型 | Qwen 3.5（397B 參數）、Google Lyria 3 音樂生成 | 中國 AI 實力崛起，多模態創意工具普及 |
| 🛠️ 工具 | GGML/llama.cpp 加入 Hugging Face | 本地 AI 生態壯大，開源力量對抗閉源圍牆 |
| ⚖️ 政策 | OpenAI/Google 舉報 DeepSeek「蒸餾攻擊」 | AI 技術冷戰升溫，監管成為新戰場 |
| 💼 職場 | 研究發現 AI 加劇工作強度，996 文化蔓延 | AI 生產力紅利伴隨著 burnout 風險 |

---

## 💡 今日洞察

**2026 年的 AI 戰場，正在從「模型能力」轉向「商業模式」。**

Anthropic 築牆、OpenAI 納客、Google 和 DeepSeek 互相指責——這些看似不相關的事件，其實都指向同一個問題：當 AI 能力越來越同質化，什麼才是真正的護城河？

Anthropic 選擇了「圍牆」——用技術手段鎖定用戶，防止套利。OpenAI 選擇了「生態」——用開放姿態吸引開發者，擴大影響力。中國公司選擇了「開源」——用低成本、高性能的開源模型，繞過西方的封鎖。

這三種策略，哪一種會贏？還沒有人知道答案。但可以確定的是：

1. **「無限量包月」模式正在退場**——當 AI agent 可以 24 小時不眠不休地工作，按人頭收費的商業模式注定不可持續
2. **「開源 vs 閉源」之爭將更加激烈**——Anthropic 築牆的同時，Hugging Face 正在壯大本地 AI 生態
3. **「AI 倦怠」將成為新挑戰**——當 AI 讓我們做得更多，而不是工作得更輕鬆，我們需要重新思考「生產力」的定義

對於個人和企業而言，2026 年的關鍵問題不是「要不要用 AI」，而是「如何在這場商業模式的重構中，找到自己的位置」。

---

*本報告由 AI 自動生成，僅供參考。投資決策請自行評估風險。*
