# 範例：AI 科技晨間匯報格式參考

這是一份高品質晨報的結構範例，供生成時參考。

---

## 標題範例

```markdown
# 🌅 AI 科技晨間匯報 | 2026-02-12

> 📅 報告日期：2026年2月12日（星期四）
> 🌍 資料時間範圍：過去一週精選
```

---

## 頭條範例（深度分析）

```markdown
## 🔥 重點頭條

### Anthropic vs OpenAI：同日發布新模型，競爭白熱化

2月5日，AI 領域兩大巨頭在同一天發布新模型，展現了這場競爭的激烈程度：

**🤖 Anthropic 推出 Claude Opus 4.6**
Anthropic 發布了目前最先進的 AI 模型 Claude Opus 4.6，在程式編寫、財務分析和法律推理等方面達到頂尖水平。該模型能夠更長時間、更可靠地執行任務，特別針對企業知識工作場景進行優化。
- 來源：[Reuters](https://www.reuters.com/...)
- 來源：[TechCrunch](https://techcrunch.com/...)

**💻 OpenAI 發布 GPT-5.3 Codex**
OpenAI 緊接著發布了專為程式設計優化的新模型 GPT-5.3 Codex...
- 來源：[TechCrunch](https://techcrunch.com/...)

**深度觀點：** 這場「同日發布」的較量反映了 AI 競爭進入白熱化階段...
```

**重點**：
- 標題用 ### 
- 有背景說明
- 分點說明不同公司/產品
- 有深度觀點分析
- 多個來源連結

---

## 分類新聞範例

```markdown
## 📊 一、大模型更新

### 1. Google 與 Anthropic 雲端合作擴大
2025 年 10 月，Anthropic 宣布與 Google 擴大雲端合作，獲得高達 100 萬個 Google 自研 TPU（張量處理單元）的使用權...
- 來源：[Wikipedia - Anthropic](https://en.wikipedia.org/wiki/Anthropic)

## 💰 三、AI 產業投資/併購動態

### 6. xAI 創紀錄 200 億美元融資
Elon Musk 的 xAI 在 2026 年 1 月初完成 200 億美元 E 輪融資...
- 來源：[Crunchbase News](https://news.crunchbase.com/...)
```

**重點**：
- 使用 ## 大標題 + ### 小標題
- 編號排序
- 簡短說明（100-150 字）
- 每則都有來源連結

---

## 摘要表格範例

```markdown
## 📋 今日重點摘要

| 類別 | 重點摘要 |
|------|----------|
| **大模型** | Anthropic Opus 4.6 vs OpenAI GPT-5.3 Codex 同日發布 |
| **企業平台** | OpenAI Frontier 進軍企業 Agent 管理市場 |
| **投資** | xAI 200 億美元融資，科技巨頭投資達 1.6 兆美元 |
| **法規** | 美國多州 AI 法規生效，80% 民眾支持監管 |
| **研究** | DeepSeek R1 引發「效率革命」 |
| **開發者** | AI Agent 從試點走向生產 |
```

---

## 完整檢查清單

生成後務必確認：

✅ 日期正確（台北時間 YYYY-MM-DD）
✅ 8-12 則新聞（含 1-2 深度頭條）
✅ 涵蓋 9 大類型
✅ 每則都有來源連結 `[名稱](URL)`
✅ 總字數 1,500-2,000 字
✅ 有摘要表格
✅ 檔案儲存到 drafts 資料夾
✅ 通知使用者審核