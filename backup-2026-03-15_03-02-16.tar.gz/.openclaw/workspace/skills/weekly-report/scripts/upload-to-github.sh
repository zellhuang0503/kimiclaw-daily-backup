#!/bin/bash
# 週報上傳至 GitHub 腳本

# 使用方法：
# ./upload-to-github.sh <草稿檔名> <文章標題> <slug>
# 範例：
# ./upload-to-github.sh weekly-report-robotaxi-2026-02-12.md "Robotaxi 革命" robotaxi-revolution-2026

DRAFT_FILE="$1"
TITLE="$2"
SLUG="$3"
DATE="${4:-$(date +%Y-%m-%d)}"

if [ -z "$DRAFT_FILE" ] || [ -z "$TITLE" ] || [ -z "$SLUG" ]; then
    echo "用法: $0 <草稿檔名> <文章標題> <slug> [日期]"
    echo "範例: $0 weekly-report-robotaxi.md 'Robotaxi 革命' robotaxi-revolution 2026-02-12"
    exit 1
fi

DRAFT_PATH="/home/node/.openclaw/workspace/drafts/$DRAFT_FILE"
REPO_PATH="/home/node/vae_new_website"
TARGET_FILE="$REPO_PATH/src/content/insights/$SLUG.mdx"

# 檢查檔案是否存在
if [ ! -f "$DRAFT_PATH" ]; then
    echo "錯誤：找不到草稿檔案 $DRAFT_PATH"
    exit 1
fi

# 提取圖片連結
FEATURED_IMAGE=$(grep -oP 'https://res\.cloudinary\.com/[^)]+' "$DRAFT_PATH" | head -1)

if [ -z "$FEATURED_IMAGE" ]; then
    echo "警告：未找到 Cloudinary 圖片連結"
    FEATURED_IMAGE=""
fi

# 提取文章摘要（第一個段落）
EXCERPT=$(grep -A 2 '^>' "$DRAFT_PATH" | head -3 | sed 's/^> //' | tr '\n' ' ' | cut -c1-150)

if [ -z "$EXCERPT" ]; then
    EXCERPT="本文探討最新的科技趨勢與其對產業的深層影響。"
fi

# 轉換為 MDX 格式
cat > "$TARGET_FILE" << EOF
---
title: "$TITLE"
slug: "$SLUG"
publishedAt: "$DATE"
excerpt: "$EXCERPT"
author: "黃老闆（Zell Huang）"
categories: ["AI與科技", "企業轉型", "趨勢觀察"]
featuredImage: "$FEATURED_IMAGE"
---

EOF

# 移除 frontmatter 後的內容附加到檔案
tail -n +2 "$DRAFT_PATH" >> "$TARGET_FILE"

echo "已建立 MDX 檔案: $TARGET_FILE"

# 推送到 GitHub
cd "$REPO_PATH" || exit 1

git add "src/content/insights/$SLUG.mdx"
git commit -m "Add weekly report: $TITLE"
git push origin main

echo "✅ 已成功上傳至 GitHub！"
echo "文章將在數分鐘後自動部署到 Netlify"
